CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$
DECLARE
    new_password text := 'duysuc123';
BEGIN
    IF new_password = 'DOI_MAT_KHAU_TRUOC_KHI_CHAY' THEN
        RAISE EXCEPTION 'Chua dat mat khau: sao chep file nay thanh Create_user.local.sql, thay mat khau roi chay ban sao do';
    END IF;
    IF char_length(new_password) < 8 OR octet_length(new_password) > 72 THEN
        RAISE EXCEPTION 'Mat khau phai co it nhat 8 ky tu va khong qua 72 byte';
    END IF;

    INSERT INTO users (username, password_hash, status)
    VALUES ('duysuc123', crypt(new_password, gen_salt('bf', 10)), 'Offline')
    ON CONFLICT (username) DO UPDATE
    SET password_hash = EXCLUDED.password_hash,
        status = 'Offline',
        cookie_hash = NULL,
        cookie_expires_at = NULL,
        updated_at = now();
END $$;